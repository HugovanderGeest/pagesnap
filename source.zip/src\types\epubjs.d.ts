declare module 'epubjs';
